util.require_natives("natives-1651208000") 
local dlay = 50
local name = "Bigassgirl Money Maker"
local ver = "0.1 Korean 한국어"
local local_name = players.get_name(players.user())
local Command = menu.ref_by_command_name("spoofname")
local Toggle = menu.get_value(Command)
local State = ""
local Spoofed = false
if Toggle then
    State = "참"
    Spoofed = true
else
    State = "거짓"
    Spoofed = false
end
------------------------------------

menu.divider(menu.my_root(), name)
util.yield(dlay)
local make_shit = "엉덩이가 큰 그녀 V1"
menu.action(menu.my_root(), make_shit , {}, "makeshit", function()
    if Spoofed == false then
     menu.trigger_commands("bounty all 10000")
     util.toast("15000ms / 15초가 소요됩니다.")
     util.yield(15000)
     menu.trigger_commands("as "..local_name.." explode all")
    elseif Spoofed == true then  
     util.toast("닉네임 스푸핑을 꺼주세요 !")
    end
end)
util.yield(dlay)
local make_shit2 = "엉덩이가 큰 그녀 V2"
menu.action(menu.my_root(), make_shit2 , {}, "makeshit2", function()
    if Spoofed == false then
     menu.trigger_commands("freezeall")
     menu.trigger_commands("disarmall")
     menu.trigger_commands("aptmeall")
     menu.trigger_commands("bounty all 15000")
     util.toast("15000ms / 15초가 소요됩니다.")
     util.yield(15000)
     menu.trigger_commands("as "..local_name.." explode all")
    elseif Spoofed == true then 
        util.toast("닉네임 스푸핑을 꺼주세요 !")
    end
end)
util.yield(dlay)
local divider_1 = "도구"
menu.divider(menu.my_root(), divider_1)
util.yield(dlay)
local go_public = "공개세션 참여하기"
menu.action(menu.my_root(), go_public, {}, "go public", function()
    menu.trigger_commands("go public")
end)
util.yield(dlay)
local divider_2 = "정보"
menu.divider(menu.my_root(), divider_2)
util.yield(dlay)
local local_name_moniter = "로컬 플레이어 닉네임 : "..local_name
menu.action(menu.my_root(), local_name_moniter , {}, "", function()
end)
util.yield(dlay)
local spoof_label = "스푸핑 유무 : "..State
menu.action(menu.my_root(), spoof_label , {}, "", function()
end)
util.yield(dlay)
local luaver_label = "스크립트 빌드 : "..ver
menu.action(menu.my_root(), luaver_label , {}, "", function()
end)
------------------------------------
util.toast("스크립트 로딩완료")
util.keep_running()