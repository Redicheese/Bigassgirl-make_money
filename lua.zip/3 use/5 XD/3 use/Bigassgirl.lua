util.require_natives("natives-1651208000") 
local dlay = 50
local name = "Bigassgirl Money Maker"
local ver = "0.1 English"
local local_name = players.get_name(players.user())
local Command = menu.ref_by_command_name("spoofname")
local Toggle = menu.get_value(Command)
local State = ""
local Spoofed = false
if Toggle then
    State = "True"
    Spoofed = true
else
    State = "False"
    Spoofed = false
end
------------------------------------

menu.divider(menu.my_root(), name)
util.yield(dlay)
local make_shit = "Make shit V1"
menu.action(menu.my_root(), make_shit , {}, "makeshit", function()
    if Spoofed == false then
     menu.trigger_commands("bounty all 10000")
     util.toast("Waiting for 15000ms ( 15s )")
     util.yield(15000)
     menu.trigger_commands("as "..local_name.." explode all")
    elseif Spoofed == true then  
     util.toast("Check Nickname Spoofing !")
    end
end)
util.yield(dlay)
local make_shit2 = "Make shit V2"
menu.action(menu.my_root(), make_shit2 , {}, "makeshit2", function()
    if Spoofed == false then
     menu.trigger_commands("freezeall")
     menu.trigger_commands("disarmall")
     menu.trigger_commands("aptmeall")
     menu.trigger_commands("bounty all 15000")
     util.toast("Waiting for 15000ms ( 15s )")
     util.yield(15000)
     menu.trigger_commands("as "..local_name.." explode all")
    elseif Spoofed == true then 
     util.toast("Check Nickname Spoofing !")
    end
end)
util.yield(dlay)
local divider_1 = "Tool"
menu.divider(menu.my_root(), divider_1)
util.yield(dlay)
local go_public = "Find Public Session"
menu.action(menu.my_root(), go_public, {}, "go public", function()
    menu.trigger_commands("go public")
end)
util.yield(dlay)
local divider_2 = "Info"
menu.divider(menu.my_root(), divider_2)
util.yield(dlay)
local local_name_moniter = "Local name : "..local_name
menu.action(menu.my_root(), local_name_moniter , {}, "", function()
end)
util.yield(dlay)
local spoof_label = "Spoofed : "..State
menu.action(menu.my_root(), spoof_label , {}, "", function()
end)
util.yield(dlay)
local luaver_label = "Script Build : "..ver
menu.action(menu.my_root(), luaver_label , {}, "", function()
end)
------------------------------------
util.toast("Script Loaded")
util.keep_running()